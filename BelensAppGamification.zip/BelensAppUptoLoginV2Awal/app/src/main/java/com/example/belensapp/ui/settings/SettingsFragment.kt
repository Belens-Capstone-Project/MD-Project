package com.example.belensapp.ui.settings

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.belensapp.R
import com.example.belensapp.databinding.FragmentSettingsBinding
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.card.MaterialCardView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import android.provider.MediaStore
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.example.belensapp.ui.login.LoginActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    private lateinit var darkModeSwitch: SwitchMaterial
    private lateinit var languageCard: MaterialCardView
    private lateinit var profileCard: MaterialCardView

    private val pickImageResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == AppCompatActivity.RESULT_OK) {
            val imageUri = result.data?.data
            imageUri?.let {
                binding.profileImage.setImageURI(imageUri)
                // Save image uri or path to SharedPreferences or database as needed
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val settingsViewModel = ViewModelProvider(this).get(SettingsViewModel::class.java)

        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textSettings
        settingsViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        // Initialize Dark Mode Switch
        setupDarkModeSwitch()

        // Update icon colors initially
        updateIconColors()

        // Language Change
        languageCard = binding.cardLanguage
        languageCard.setOnClickListener {
            showLanguageChangeDialog()
        }

        // Profile Change
        profileCard = binding.cardChangeProfile
        profileCard.setOnClickListener {
            findNavController().navigate(R.id.action_settingsFragment_to_profileFragment)
        }

        // Logout
        val logoutCard: MaterialCardView = binding.cardLogout
        logoutCard.setOnClickListener {
            logoutUser()
        }

        updateBadgeColors()

        // Load Profile Photo
        loadProfilePhoto()

        return root
    }
    private fun saveBadgeStatus(badgeNumber: Int, isAchieved: Boolean) {
        val sharedPref = requireContext().getSharedPreferences("badge_status", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putBoolean("badge_$badgeNumber", isAchieved)
            apply()
        }
    }

    private fun getBadgeStatus(badgeNumber: Int): Boolean {
        val sharedPref = requireContext().getSharedPreferences("badge_status", Context.MODE_PRIVATE)
        return sharedPref.getBoolean("badge_$badgeNumber", false)
    }

    private fun updateBadgeColors() {
        if (getBadgeStatus(1)) {
            binding.badge1Gray.visibility = View.GONE
            binding.badge1Color.visibility = View.VISIBLE
        }
        if (getBadgeStatus(2)) {
            binding.badge2Gray.visibility = View.GONE
            binding.badge2Color.visibility = View.VISIBLE
        }
        if (getBadgeStatus(3)) {
            binding.badge3Gray.visibility = View.GONE
            binding.badge3Color.visibility = View.VISIBLE
        }
        if (getBadgeStatus(4)) {
            binding.badge4Gray.visibility = View.GONE
            binding.badge4Color.visibility = View.VISIBLE
        }
        if (getBadgeStatus(5)) {
            binding.badge5Gray.visibility = View.GONE
            binding.badge5Color.visibility = View.VISIBLE
        }
    }



    private fun setupDarkModeSwitch() {
        darkModeSwitch = binding.darkModeSwitch
        // Load saved dark mode state
        val sharedPref = requireContext().getSharedPreferences("app_pref", Context.MODE_PRIVATE)
        val isDarkMode = sharedPref.getBoolean("is_dark_mode", false)
        darkModeSwitch.isChecked = isDarkMode

        darkModeSwitch.setOnCheckedChangeListener { _, isChecked ->
            toggleDarkMode(isChecked)
            updateIconColors()
        }
    }

    private fun saveDarkModeState(isEnabled: Boolean) {
        val sharedPref = requireContext().getSharedPreferences("app_pref", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putBoolean("is_dark_mode", isEnabled)
            apply()
        }
    }

    private fun toggleDarkMode(isEnabled: Boolean) {
        if (isEnabled) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
        saveDarkModeState(isEnabled)
    }

    private fun updateIconColors() {
        val isDarkMode = isDarkModeEnabled()
        val iconColor = if (isDarkMode) {
            requireContext().getColor(android.R.color.white)
        } else {
            requireContext().getColor(android.R.color.black)
        }

        binding.languageIcon.setColorFilter(iconColor)
        binding.changeProfileIcon.setColorFilter(iconColor)
        binding.logoutIcon.setColorFilter(iconColor)
    }

    private fun isDarkModeEnabled(): Boolean {
        val sharedPref = requireContext().getSharedPreferences("app_pref", Context.MODE_PRIVATE)
        return sharedPref.getBoolean("is_dark_mode", false)
    }

    private fun showLanguageChangeDialog() {
        val languages = arrayOf("English", "Bahasa Indonesia")
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle(getString(R.string.choose_language))
        builder.setItems(languages) { _, which ->
            when (which) {
                0 -> changeLanguage("en")
                1 -> changeLanguage("id")
            }
        }
        builder.show()
    }

    private fun changeLanguage(languageCode: String) {
        // Save selected language to SharedPreferences
        val sharedPref = requireContext().getSharedPreferences("app_pref", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putString("selected_language", languageCode)
            apply()
        }

        // Update locale configuration
        val locale = java.util.Locale(languageCode)
        java.util.Locale.setDefault(locale)
        val config = requireContext().resources.configuration
        config.setLocale(locale)
        requireContext().resources.updateConfiguration(config, requireContext().resources.displayMetrics)

        // Show toast message
        Toast.makeText(
            requireContext(),
            getString(R.string.language_changed_to) + " $languageCode",
            Toast.LENGTH_SHORT
        ).show()

        // Refresh current fragment by navigating back to settings
        findNavController().navigate(R.id.action_settingsFragment_self)
    }

    private fun logoutUser() {
        // Logout from Firebase Authentication
        FirebaseAuth.getInstance().signOut()

        // Clear user data from SharedPreferences
        val sharedPref = requireContext().getSharedPreferences("user_pref", AppCompatActivity.MODE_PRIVATE)
        with(sharedPref.edit()) {
            clear()
            apply()
        }

        // Show logout confirmation
        Toast.makeText(requireContext(), "Logged out successfully", Toast.LENGTH_SHORT).show()

        // Navigate to Login Activity and clear activity stack
        val intent = Intent(requireContext(), LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        startActivity(intent)

        // Finish current activity
        requireActivity().finish()
    }

    private fun loadProfilePhoto() {
        val sharedPref = requireContext().getSharedPreferences("user_pref", Context.MODE_PRIVATE)
        val userToken = sharedPref.getString("user_token", null) ?: return

        val databaseRef = FirebaseDatabase.getInstance("https://belensapp-8eff1-default-rtdb.asia-southeast1.firebasedatabase.app")
            .getReference("user/$userToken")

        databaseRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val photoUrl = snapshot.child("photoUrl").getValue(String::class.java)
                    if (!photoUrl.isNullOrEmpty()) {
                        Glide.with(requireContext())
                            .load(photoUrl)
                            .circleCrop()
                            .into(binding.profileImage)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Failed to load photo: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}