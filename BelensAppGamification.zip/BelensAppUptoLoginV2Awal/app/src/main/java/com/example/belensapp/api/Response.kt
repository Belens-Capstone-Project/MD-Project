//package com.example.belensapp.api
//
//import com.google.gson.annotations.SerializedName
//
//data class Response(
//
//	@field:SerializedName("Response")
//	val response: List<ResponseItem?>? = null
//)
//
//data class ResponseItem(
//
//	@field:SerializedName("imageUrl")
//	val imageUrl: String? = null,
//
//	@field:SerializedName("description")
//	val description: String? = null,
//
//	@field:SerializedName("title")
//	val title: String? = null,
//
//	@field:SerializedName("url")
//	val url: String? = null
//)
