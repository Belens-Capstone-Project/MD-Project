package com.example.belensapp.utils

object Constants {
    const val PREF_NAME = "user_pref"
    const val KEY_USER_TOKEN = "user_token"
    const val KEY_USERNAME = "username"
}